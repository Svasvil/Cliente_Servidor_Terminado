
package autenticacionusuarios.avance3;


public class Codigo_DB {
   /* 

CREATE DATABASE RestaurantesDB;

USE RestaurantesDB;

CREATE TABLE Restaurantes (
    ID_Restaurantes INT PRIMARY KEY,
    Nombre_Restaurante VARCHAR(50),
    Precio_Plato DECIMAL(10, 2),
    Direccion VARCHAR(50)
);

INSERT INTO Restaurantes (ID_Restaurantes, Nombre_Restaurante, Precio_Plato, Direccion) VALUES
(1, 'Pizza hut', 1555, 'San Jose'),
(2, 'MacDonalds', 1000, 'Heredia'),
(3, 'Burger King', 2000, 'Alajuela'),
(4, 'Taco bell', 1255, 'Cartago');    
*/    
}
